export { default } from '../ApplicantDetailModal';
