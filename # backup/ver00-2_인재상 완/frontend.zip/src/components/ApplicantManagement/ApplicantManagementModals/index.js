export { default } from '../ApplicantManagementModals';
