#!/usr/bin/env python3
"""
인재상 관리 툴을 테스트하는 스크립트
"""
import asyncio
import aiohttp
import json

async def test_company_culture_tool():
    url = "http://localhost:8000/api/react-agent/process-input"

    # 테스트 1: 인재상 목록 조회
    print("🧪 테스트 1: 인재상 목록 조회")
    test_data_1 = {
        "session_id": "test_session_123",
        "user_input": "인재상 목록을 보여줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_1) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "="*50 + "\n")

    # 테스트 2: 인재상 생성
    print("🧪 테스트 2: 인재상 생성")
    test_data_2 = {
        "session_id": "test_session_123",
        "user_input": "새로운 인재상을 만들어줘. 이름은 '혁신적 사고'이고, 설명은 '새로운 아이디어를 창출하고 문제를 창의적으로 해결하는 능력'이야."
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_2) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

if __name__ == "__main__":
    print("🚀 인재상 관리 툴 테스트를 시작합니다...")
    asyncio.run(test_company_culture_tool())
