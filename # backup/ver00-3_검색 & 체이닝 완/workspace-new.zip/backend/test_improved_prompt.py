#!/usr/bin/env python3
"""
개선된 프롬프트로 인재상 생성 테스트를 하는 스크립트
"""
import asyncio
import aiohttp
import json

async def test_improved_prompt():
    url = "http://localhost:8000/api/react-agent/process-input"

    # 테스트 1: 인재상 생성 요청 (개선된 버전)
    print("🧪 테스트 1: 인재상 생성 요청 (개선된 버전)")
    test_data_1 = {
        "session_id": "test_session_123",
        "user_input": "협력과 책임감을 중시하는 인재상을 만들어줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_1) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 툴 실행 여부 확인
                    if result.get("suggested_tool") == "company_culture":
                        print("🎯 ✅ 인재상 툴이 올바르게 매핑되었습니다!")

                        # 생성된 인재상 정보 확인
                        tool_result = result.get("tool_result", {})
                        if tool_result and "data" in tool_result:
                            culture_data = tool_result["data"]
                            print(f"📝 생성된 인재상:")
                            print(f"  - 이름: {culture_data.get('name', 'N/A')}")
                            print(f"  - 설명: {culture_data.get('description', 'N/A')}")

                            # 사용자 요청이 반영되었는지 확인
                            if "협력과 책임감" in culture_data.get('name', ''):
                                print("✅ 사용자 요청이 이름에 반영되었습니다!")
                            else:
                                print("❌ 사용자 요청이 이름에 반영되지 않았습니다.")

                            if "협력과 책임감" in culture_data.get('description', ''):
                                print("✅ 사용자 요청이 설명에 반영되었습니다!")
                            else:
                                print("❌ 사용자 요청이 설명에 반영되지 않았습니다.")
                    else:
                        print("❌ 인재상 툴 매핑 실패")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "="*50 + "\n")

    # 테스트 2: 다른 패턴의 인재상 생성
    print("🧪 테스트 2: 다른 패턴의 인재상 생성")
    test_data_2 = {
        "session_id": "test_session_123",
        "user_input": "창의적이고 혁신적인 인재상을 만들어줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_2) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 생성된 인재상 정보 확인
                    tool_result = result.get("tool_result", {})
                    if tool_result and "data" in tool_result:
                        culture_data = tool_result["data"]
                        print(f"📝 생성된 인재상:")
                        print(f"  - 이름: {culture_data.get('name', 'N/A')}")
                        print(f"  - 설명: {culture_data.get('description', 'N/A')}")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

if __name__ == "__main__":
    print("🚀 개선된 인재상 생성 기능 테스트를 시작합니다...")
    asyncio.run(test_improved_prompt())
