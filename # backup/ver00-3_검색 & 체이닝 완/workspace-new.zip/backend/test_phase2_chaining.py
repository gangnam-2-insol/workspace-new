#!/usr/bin/env python3
"""
Phase 2 체이닝 고급 기능 테스트 스크립트
- 병렬 실행 (독립 작업)
- 재시도 로직
- 체이닝 템플릿
- 성능 측정
"""
import asyncio
import aiohttp
import json
import time

async def test_phase2_chaining():
    url = "http://localhost:8000/api/react-agent/process-input"

    print("🚀 Phase 2 체이닝 고급 기능 테스트를 시작합니다...")
    print("=" * 60)

    # 테스트 1: 독립 작업 병렬 실행 테스트
    print("🧪 테스트 1: 독립 작업 병렬 실행")
    print("📝 요청: 'React 개발자 채용공고 작성하고 동시에 Python 개발자 채용공고도 작성해줘'")

    test_data_1 = {
        "session_id": "test_phase2_parallel",
        "user_input": "React 개발자 채용공고 작성하고 동시에 Python 개발자 채용공고도 작성해줘"
    }

    start_time = time.time()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_1) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    execution_time = time.time() - start_time

                    print(f"✅ 성공 응답 (실행 시간: {execution_time:.2f}초):")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 병렬 실행 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"\n🔍 체이닝 결과 분석:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 병렬 작업 수: {chaining_results.get('parallel_tasks', 0)}")
                        print(f"  - 순차 작업 수: {chaining_results.get('sequential_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                        # 성능 정보 확인
                        performance = chaining_results.get("performance_summary", {})
                        print(f"\n⚡ 성능 정보:")
                        print(f"  - 병렬 실행 여부: {performance.get('parallel_execution', False)}")
                        print(f"  - 효율성 개선: {performance.get('efficiency_gain', 'N/A')}")

                        # 실행 상세 정보
                        execution_details = chaining_results.get("execution_details", [])
                        print(f"\n📊 실행 상세 정보:")
                        for detail in execution_details:
                            execution_type = detail.get("execution_type", "unknown")
                            status = detail.get("status", "unknown")
                            tool = detail.get("tool", "unknown")
                            action = detail.get("action", "unknown")
                            print(f"  - {execution_type.upper()}: {tool}.{action} ({status})")
                    else:
                        print("❌ 체이닝 결과가 없습니다.")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "=" * 60)

    # 테스트 2: 재시도 로직 테스트 (의도적으로 실패할 수 있는 작업)
    print("🧪 테스트 2: 재시도 로직 테스트")
    print("📝 요청: '존재하지 않는 툴로 작업하고 그 다음에 정상 작업 실행해줘'")

    test_data_2 = {
        "session_id": "test_phase2_retry",
        "user_input": "존재하지 않는 툴로 작업하고 그 다음에 정상 작업 실행해줘"
    }

    start_time = time.time()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_2) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    execution_time = time.time() - start_time

                    print(f"✅ 성공 응답 (실행 시간: {execution_time:.2f}초):")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 재시도 로직 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"\n🔄 재시도 로직 결과:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                        # 실행 상세 정보에서 재시도 확인
                        execution_details = chaining_results.get("execution_details", [])
                        print(f"\n📊 실행 상세 정보:")
                        for detail in execution_details:
                            status = detail.get("status", "unknown")
                            tool = detail.get("tool", "unknown")
                            action = detail.get("action", "unknown")
                            error = detail.get("error", "")
                            print(f"  - {tool}.{action}: {status}")
                            if error:
                                print(f"    오류: {error}")
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "=" * 60)

    # 테스트 3: 복합 체이닝 (병렬 + 순차)
    print("🧪 테스트 3: 복합 체이닝 (병렬 + 순차)")
    print("📝 요청: 'React 개발자와 Python 개발자 채용공고를 동시에 작성하고, 완료되면 이메일로 알림을 보내줘'")

    test_data_3 = {
        "session_id": "test_phase2_complex",
        "user_input": "React 개발자와 Python 개발자 채용공고를 동시에 작성하고, 완료되면 이메일로 알림을 보내줘"
    }

    start_time = time.time()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_3) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    execution_time = time.time() - start_time

                    print(f"✅ 성공 응답 (실행 시간: {execution_time:.2f}초):")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 복합 체이닝 결과 분석
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"\n🔍 복합 체이닝 결과 분석:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 병렬 작업 수: {chaining_results.get('parallel_tasks', 0)}")
                        print(f"  - 순차 작업 수: {chaining_results.get('sequential_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                        # 성능 정보
                        performance = chaining_results.get("performance_summary", {})
                        print(f"\n⚡ 성능 정보:")
                        print(f"  - 병렬 실행 여부: {performance.get('parallel_execution', False)}")
                        print(f"  - 효율성 개선: {performance.get('efficiency_gain', 'N/A')}")

                        # 실행 순서 확인
                        execution_details = chaining_results.get("execution_details", [])
                        print(f"\n📊 실행 순서:")
                        for i, detail in enumerate(execution_details):
                            execution_type = detail.get("execution_type", "unknown")
                            tool = detail.get("tool", "unknown")
                            action = detail.get("action", "unknown")
                            status = detail.get("status", "unknown")
                            print(f"  {i+1}. [{execution_type.upper()}] {tool}.{action} - {status}")
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "=" * 60)

    # 테스트 4: 체이닝 템플릿 테스트
    print("🧪 테스트 4: 체이닝 템플릿 테스트")
    print("📝 요청: '채용공고 작성하고 이메일 발송 템플릿을 사용해서 작업해줘'")

    test_data_4 = {
        "session_id": "test_phase2_template",
        "user_input": "채용공고 작성하고 이메일 발송 템플릿을 사용해서 작업해줘"
    }

    start_time = time.time()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_4) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    execution_time = time.time() - start_time

                    print(f"✅ 성공 응답 (실행 시간: {execution_time:.2f}초):")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 템플릿 사용 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"\n📋 템플릿 사용 결과:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                        # 작업 패턴 확인
                        execution_details = chaining_results.get("execution_details", [])
                        print(f"\n🔍 작업 패턴 분석:")
                        for detail in execution_details:
                            tool = detail.get("tool", "unknown")
                            action = detail.get("action", "unknown")
                            status = detail.get("status", "unknown")
                            print(f"  - {tool}.{action}: {status}")

                            # 템플릿 패턴 매칭 확인
                            if tool == "job_posting" and action == "create":
                                print(f"    ✅ 채용공고 생성 템플릿 매칭")
                            elif tool == "mail" and action == "send_individual":
                                print(f"    ✅ 이메일 발송 템플릿 매칭")
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "=" * 60)
    print("🎉 Phase 2 체이닝 고급 기능 테스트 완료!")
    print("\n📊 테스트 요약:")
    print("✅ 병렬 실행 (독립 작업 동시 처리)")
    print("✅ 재시도 로직 (실패 시 자동 재시도)")
    print("✅ 체이닝 템플릿 (자주 사용하는 작업 시퀀스)")
    print("✅ 성능 측정 (병렬 vs 순차 실행 비교)")
    print("✅ 고급 응답 빌더 (실행 타입별 결과 분류)")

if __name__ == "__main__":
    print("🚀 Phase 2 체이닝 고급 기능 테스트를 시작합니다...")
    asyncio.run(test_phase2_chaining())
