#!/usr/bin/env python3
"""
동적 메시지 생성기 테스트 스크립트
"""

import os
import sys

# 프로젝트 루트를 Python 경로에 추가
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.ai.services.dynamic_message_generator import DynamicMessageGenerator


def test_dynamic_messages():
    """동적 메시지 생성 테스트"""
    print("🚀 동적 메시지 생성기 테스트 시작\n")

    # 메시지 생성기 초기화
    message_generator = DynamicMessageGenerator()

    # 1. 기본 인사말 테스트
    print("1️⃣ 기본 인사말 테스트:")
    for i in range(3):
        message = message_generator.generate_contextual_message({})
        print(f"   {i+1}. {message}")
    print()

    # 2. 채용공고 작성 단계별 메시지 테스트
    print("2️⃣ 채용공고 작성 단계별 메시지 테스트:")

    # 제목 입력 후
    context = {
        'current_page': 'job_posting',
        'current_step': 'title',
        'previous_input': {'title': '프론트엔드 개발자'},
        'user_tone': 'friendly',
        'completed_steps': ['title'],
        'progress': 0.2
    }
    message = message_generator.generate_contextual_message(context)
    print(f"   제목 입력 후: {message}")

    # 부서 입력 후
    context['current_step'] = 'department'
    context['previous_input']['department'] = '개발팀'
    context['completed_steps'] = ['title', 'department']
    context['progress'] = 0.4
    message = message_generator.generate_contextual_message(context)
    print(f"   부서 입력 후: {message}")

    # 경력 입력 후
    context['current_step'] = 'experience'
    context['previous_input']['experience'] = '3-5년'
    context['completed_steps'] = ['title', 'department', 'experience']
    context['progress'] = 0.6
    message = message_generator.generate_contextual_message(context)
    print(f"   경력 입력 후: {message}")

    # 급여 입력 후
    context['current_step'] = 'salary'
    context['previous_input']['salary'] = '5000만원'
    context['completed_steps'] = ['title', 'department', 'experience', 'salary']
    context['progress'] = 0.8
    message = message_generator.generate_contextual_message(context)
    print(f"   급여 입력 후: {message}")

    # 근무지 입력 후 (완성)
    context['current_step'] = 'location'
    context['previous_input']['location'] = '서울 강남구'
    context['completed_steps'] = ['title', 'department', 'experience', 'salary', 'location']
    context['progress'] = 1.0
    message = message_generator.generate_contextual_message(context)
    print(f"   근무지 입력 후: {message}")
    print()

    # 3. 이력서 분석 단계별 메시지 테스트
    print("3️⃣ 이력서 분석 단계별 메시지 테스트:")

    # 업로드 단계
    context = {
        'current_page': 'resume_analysis',
        'current_step': 'upload',
        'previous_input': {},
        'user_tone': 'friendly',
        'completed_steps': [],
        'progress': 0.0
    }
    message = message_generator.generate_contextual_message(context)
    print(f"   업로드 단계: {message}")

    # 분석 중
    context['current_step'] = 'analyzing'
    context['progress'] = 0.5
    message = message_generator.generate_contextual_message(context)
    print(f"   분석 중: {message}")

    # 완료
    context['current_step'] = 'complete'
    context['progress'] = 1.0
    message = message_generator.generate_contextual_message(context)
    print(f"   완료: {message}")
    print()

    # 4. 후속 메시지 테스트
    print("4️⃣ 후속 메시지 테스트:")
    for i in range(1, 6):
        context['completed_steps'] = list(range(i))
        context['progress'] = i / 5
        message = message_generator.generate_follow_up_message(context)
        print(f"   {i}단계 완료: {message}")
    print()

    # 5. 격려 메시지 테스트
    print("5️⃣ 격려 메시지 테스트:")
    for progress in [0.1, 0.3, 0.5, 0.7, 0.9]:
        context['progress'] = progress
        message = message_generator.generate_encouragement_message(context)
        print(f"   진행률 {progress*100}%: {message}")
    print()

    # 6. 톤별 메시지 테스트
    print("6️⃣ 톤별 메시지 테스트:")
    for tone in ['formal', 'casual', 'friendly']:
        message = message_generator.tone_templates[tone]['greeting']
        print(f"   {tone} 톤: {message}")
    print()

    print("✅ 모든 테스트 완료!")

if __name__ == "__main__":
    test_dynamic_messages()
