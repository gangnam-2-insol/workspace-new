#!/usr/bin/env python3
"""
send-individual-mail API를 테스트하는 스크립트
"""

import asyncio
import aiohttp
import json

async def test_mail_api():
    """메일 API를 테스트합니다."""

    url = "http://localhost:8000/api/send-individual-mail"

    # 테스트 데이터
    test_data = {
        "recipient": "test@example.com",
        "template": "불합격 통지",
        "input_text": "테스트 메일 발송"
    }

    print(f"📧 API 테스트 시작: {url}")
    print(f"📧 테스트 데이터: {json.dumps(test_data, ensure_ascii=False, indent=2)}")

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"📧 성공 응답: {json.dumps(result, ensure_ascii=False, indent=2)}")
                else:
                    error_text = await response.text()
                    print(f"📧 오류 응답: {error_text}")

    except aiohttp.ClientConnectorError:
        print("❌ 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인하세요.")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

if __name__ == "__main__":
    print("🚀 메일 API 테스트를 시작합니다...")
    asyncio.run(test_mail_api())
