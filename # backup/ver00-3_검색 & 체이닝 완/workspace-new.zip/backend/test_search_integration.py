#!/usr/bin/env python3
"""
검색 통합 기능 테스트 스크립트
"""

import asyncio
import sys
import os

# 네이버 API 키 직접 설정 (테스트용)
os.environ["NAVER_CLIENT_ID"] = "3wwdeUS4jpFbyLUZm1Km"
os.environ["NAVER_CLIENT_SECRET"] = "CtOlCKeuzh"

# 프로젝트 루트를 Python 경로에 추가
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

async def test_search_integration():
    """검색 통합 기능 테스트"""
    try:
        print("🔍 검색 통합 기능 테스트 시작...")

        # react_agent_router에서 검색 함수들 import
        from routers.react_agent_router import _get_search_type_from_query, _execute_search_tool

        # 테스트 케이스들
        test_cases = [
            ("React 개발자 정보", "blog_search"),
            ("React 개발자 뉴스", "news_search"),
            ("React 개발자 지식인", "kin_search"),
            ("React 개발자 이미지", "image_search"),
            ("React 개발자 쇼핑", "shop_search"),
            ("React 개발자 책", "book_search"),
            ("React 개발자 블로그", "blog_search"),
            ("React 개발자 후기", "blog_search"),
            ("React 개발자 질문", "kin_search"),
            ("React 개발자 최신", "news_search"),
        ]

        print("\n🔍 자동 타입 매핑 테스트...")
        for query, expected_type in test_cases:
            detected_type = _get_search_type_from_query(query)
            status = "✅" if detected_type == expected_type else "❌"
            print(f"{status} '{query}' → {detected_type} (예상: {expected_type})")

        # 실제 검색 실행 테스트
        print("\n🔍 실제 검색 실행 테스트...")
        test_query = "React 개발자"

        # 블로그 검색 테스트
        print(f"\n📝 블로그 검색 테스트: {test_query}")
        blog_result = await _execute_search_tool("blog_search", {"query": test_query})
        if blog_result["success"]:
            print(f"✅ 블로그 검색 성공!")
            print(f"📊 메시지: {blog_result['result']['message']}")
        else:
            print(f"❌ 블로그 검색 실패: {blog_result.get('error')}")

        # 뉴스 검색 테스트
        print(f"\n📰 뉴스 검색 테스트: {test_query}")
        news_result = await _execute_search_tool("news_search", {"query": test_query})
        if news_result["success"]:
            print(f"✅ 뉴스 검색 성공!")
            print(f"📊 메시지: {news_result['result']['message']}")
        else:
            print(f"❌ 뉴스 검색 실패: {news_result.get('error')}")

        # 지식iN 검색 테스트
        print(f"\n💡 지식iN 검색 테스트: {test_query}")
        kin_result = await _execute_search_tool("kin_search", {"query": test_query})
        if kin_result["success"]:
            print(f"✅ 지식iN 검색 성공!")
            print(f"📊 메시지: {kin_result['result']['message']}")
        else:
            print(f"❌ 지식iN 검색 실패: {kin_result.get('error')}")

        print("\n🎉 검색 통합 기능 테스트 완료!")

    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_search_integration())
