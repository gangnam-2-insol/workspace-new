#!/usr/bin/env python3
"""
합격 메일 템플릿으로 메일을 보내는 테스트 스크립트
"""
import asyncio
import aiohttp
import json

async def test_passed_email():
    url = "http://localhost:8000/api/send-individual-mail"
    email_data = {
        "recipient": "kyunghol87@naver.com",
        "template": "합격 메일 템플릿",
        "input_text": "kyunghol87@naver.com에게 합격 메일 보내줘"
    }

    print(f"📧 합격 메일 API 테스트 시작")
    print(f"📧 수신자: {email_data['recipient']}")
    print(f"📧 템플릿: {email_data['template']}")

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=email_data) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

if __name__ == "__main__":
    print("🚀 합격 메일 API 테스트를 시작합니다...")
    asyncio.run(test_passed_email())
