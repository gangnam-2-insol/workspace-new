#!/usr/bin/env python3
"""
체이닝 기능을 테스트하는 스크립트
"""
import asyncio
import aiohttp
import json

async def test_chaining():
    url = "http://localhost:8000/api/react-agent/process-input"

    # 테스트 1: 체이닝 작업 - 채용공고 작성 + 이메일 발송
    print("🧪 테스트 1: 체이닝 작업 - 채용공고 작성 + 이메일 발송")
    test_data_1 = {
        "session_id": "test_session_123",
        "user_input": "프론트엔드 개발자 채용공고 작성하고 완료 알림 이메일 보내줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_1) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 체이닝 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"🔗 체이닝 결과:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                        # 실행 상세 정보
                        execution_details = chaining_results.get("execution_details", [])
                        for i, detail in enumerate(execution_details):
                            status = "✅" if detail.get("status") == "success" else "❌"
                            print(f"    {i+1}. {status} {detail.get('tool')}.{detail.get('action')}")
                    else:
                        print("❌ 체이닝 결과가 없습니다.")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "="*50 + "\n")

    # 테스트 2: 체이닝 작업 - 인재상 생성 + 지원자 평가
    print("🧪 테스트 2: 체이닝 작업 - 인재상 생성 + 지원자 평가")
    test_data_2 = {
        "session_id": "test_session_123",
        "user_input": "협력과 책임감을 중시하는 인재상을 만들고 지원자 A를 평가해줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_2) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 체이닝 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"🔗 체이닝 결과:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

    print("\n" + "="*50 + "\n")

    # 테스트 3: 체이닝 작업 - 검색 + 채용공고 작성
    print("🧪 테스트 3: 체이닝 작업 - 검색 + 채용공고 작성")
    test_data_3 = {
        "session_id": "test_session_123",
        "user_input": "React 개발자 시장 동향 검색하고 그에 맞는 채용공고 작성해줘"
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=test_data_3) as response:
                print(f"📧 응답 상태 코드: {response.status}")

                if response.status == 200:
                    result = await response.json()
                    print(f"✅ 성공 응답:")
                    print(json.dumps(result, ensure_ascii=False, indent=2))

                    # 체이닝 결과 확인
                    chaining_results = result.get("chaining_results", {})
                    if chaining_results:
                        print(f"🔗 체이닝 결과:")
                        print(f"  - 총 작업 수: {chaining_results.get('total_tasks', 0)}")
                        print(f"  - 성공 작업 수: {chaining_results.get('successful_tasks', 0)}")
                        print(f"  - 실패 작업 수: {chaining_results.get('failed_tasks', 0)}")

                else:
                    error_text = await response.text()
                    print(f"❌ 오류 응답: {error_text}")
    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")

if __name__ == "__main__":
    print("🚀 체이닝 기능 테스트를 시작합니다...")
    asyncio.run(test_chaining())
