#!/usr/bin/env python3
"""
네이버 검색 API 테스트 스크립트
"""

import asyncio
import sys
import os

# 네이버 API 키 직접 설정 (테스트용)
os.environ["NAVER_CLIENT_ID"] = "3wwdeUS4jpFbyLUZm1Km"
os.environ["NAVER_CLIENT_SECRET"] = "CtOlCKeuzh"

# 프로젝트 루트를 Python 경로에 추가
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

async def test_naver_search():
    """네이버 검색 API 테스트"""
    try:
        print("🔍 네이버 검색 API 테스트 시작...")
        print(f"🔑 Client ID: {os.environ.get('NAVER_CLIENT_ID')}")
        print(f"🔑 Client Secret: {os.environ.get('NAVER_CLIENT_SECRET')}")

        # 네이버 검색 서비스 import
        from modules.core.services.naver_search_service import naver_search_service

        # 테스트 검색어
        test_query = "React 개발자"
        print(f"📝 테스트 검색어: {test_query}")

        # 다양한 검색 타입 테스트
        search_types = ["web", "blog", "news", "kin", "shop", "book", "encyc", "image"]

        for search_type in search_types:
            print(f"\n🔍 {search_type} 검색 테스트...")
            try:
                if search_type == "web":
                    result = await naver_search_service.search_web(test_query, display=3)
                elif search_type == "blog":
                    result = await naver_search_service.search_blog(test_query, display=3)
                elif search_type == "news":
                    result = await naver_search_service.search_news(test_query, display=3)
                elif search_type == "kin":
                    result = await naver_search_service.search_kin(test_query, display=3)
                else:
                    # 다른 검색 타입은 직접 호출
                    result = await naver_search_service._search(search_type, test_query, display=3)

                if result["success"]:
                    print(f"✅ {search_type} 검색 성공!")
                    print(f"📊 총 결과: {result['data']['total_results']}개")
                    print(f"🔗 소스: {result['data']['source']}")
                else:
                    print(f"❌ {search_type} 검색 실패: {result.get('message', '알 수 없는 오류')}")

            except Exception as e:
                print(f"❌ {search_type} 검색 중 오류: {str(e)}")

        print("\n🎉 네이버 검색 API 테스트 완료!")

    except Exception as e:
        print(f"❌ 테스트 중 오류 발생: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_naver_search())
